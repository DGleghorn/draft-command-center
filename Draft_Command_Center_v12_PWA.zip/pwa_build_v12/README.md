# Draft Command Center v12 PWA

Upload the contents of this folder to the root of the GitHub Pages repository. Open the HTTPS GitHub Pages URL in Safari, then use Share -> Add to Home Screen.

v12 includes improved mock-draft team logic: realistic starter-first roster construction, QB/TE checkpoints, position ceilings, skill-player depth priorities, and DEF/K reserved for the final two rounds.

ESPN private-league live sync still requires a secure server-side connector.
